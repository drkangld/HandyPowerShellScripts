##
#Header
#




Set-Location "F:\git\Get-TFSSecurityReport\Get-TFSSecurityReport"
Clear
Write-host "Starting Script" -ForegroundColor Green

#TFS AD Groups I want to query. This is an Array of strings
$TFSGroups = ("AXGSUBBatchUsers","AXGSUBDev","AXGSUBDEVOneKey","AXGSUBFirefighter","AXGSUBITSupport","AXGSUBServiceAcct","Dynamics AX Developers","Dynamics AX Devs","Dynamics AX Users","EnvistaDevs","IT_SERVICES_APPLICATION_DEVELOPMENT","MCA Connect","ServerAdmins","SonataAXDev","TFS2Admin")
Write-Host "`nNumber of AD Groups detected $($TFSGroups.Length)" -ForegroundColor Green


#SQL Connection Variables
$SQLServer = "BRKTFS2"
$Database = "TFS_Configuration"
$SQLResults = ''
Write-Host "`nSetting up SQL Connection to $SQLServer.$Database.. " -ForegroundColor Green

#SQL Query Results. HardSet Path for testing CHANGE THis
Write-Host "   Querying Database..." -ForegroundColor Yellow
$SQLResults = $(Invoke-Sqlcmd -ServerInstance $($SQLServer) -Database $($Database) -InputFile "$PSScriptroot\..\sql\sql-Get_TFS_Users.sql")
#$SQLResults = $(Invoke-Sqlcmd -ServerInstance $($SQLServer) -Database $($Database) -InputFile "F:\git\Get-TFSSecurityReport\Get-TFSSecurityReport\sql\sql-Get_TFS_Users.sql")
Write-Host "   $($SQLResults.count) records received..." -ForegroundColor Yellow

#Create array of base columns from original SQL results to setup data table headers dynamically
#Initial SQL columns: TypeId,Id,DisplayName,Description,Domain,AccountName,DistinguishedName,MailAddress,IsGroup,LastSync
#$BaseColumns is an array of strings.
$BaseColumns = $($SQLResults[0] | gm | select Name,MemberType | where {$_.MemberType -eq "Property"}).Name
Write-Host "`nNumber of Base Columns from TFS SQL Query: $($($($BaseColumns).length))" -ForegroundColor Green

#Build a "Data Table"
Write-Host "`nBuilding User DataTable...`n" -ForegroundColor Green

#Initialize the DataTable
$DataTable = $null
$DataTable = New-Object System.Data.DataTable

Write-Host "Creating DataTable Columns dynamically from SQL Query..." -ForegroundColor Green
#Create Columns for new Data Table from SQLResults and set data type
#In this case there are a few columns that I want to be different from just a string, so I'm using a switch
#Using pipe to Out-Null to be less noisy on the console.
foreach ($c in $BaseColumns) {
    write-host "   Adding column $c" -ForegroundColor Yellow
    switch ($c){
       "LastSync" {$DataTable.Columns.Add("$c","System.Datetime") | Out-Null} 
       "IsGroup"  {$DataTable.Columns.Add("$c","System.Boolean") | Out-Null}
       default {$DataTable.Columns.Add("$c","System.String") | Out-Null}
    }
}
Write-Host "Columns created..." -ForegroundColor Green
Write-Host "Populating DataTable..." -ForegroundColor Green

#Populate the Data Table with the base info from the SQL results (Process each row and assign values to new row column)
foreach ($r in $SQLResults) {
    #Create a new Row Object
    $Row = $DataTable.NewRow()
    #Dynamically add the data for each row element to the new row object
    foreach ($bc in $BaseColumns) {
        #Write-host "column is $bc"
        $Row.$($bc) = $r.$($bc)
    }
    #Add the new row to the DataTable
    $DataTable.Rows.Add($Row)
}

Write-Host "Number of rows in Data Table: $($DataTable | Measure-Object | select -ExpandProperty count)" -ForegroundColor Green

# Check which users are enabled, Add to Data Table
#Add New column "IsEnabled" to Data Table
#$IsEnabled = $(Get-ADUser -Filter {name -like $user -or samaccountname -like $user} | Select Enabled)

$DataTable.Columns.Add("IsEnabled",[Boolean]) | Out-Null
#$IsEnabledColumn.DefaultValue = $false

#Add Column definition to DataTable$$DataTable.Columns.Add("$IsEnabled") and populate
#Add 'IsEnabled' Column and populate.
#In this case, I'm looking up but Sid because users can have various display or samAccountName aliases.
#If the user is in our AD, they will have a SID.
#If the user is gone and deleted from AD or some weird edge case where they were external to our AD, I'm considering them as
#    'Disabled' and fair game for removal
#The 'IsEnabled column is boolean for that reason and the default value is $false
#If we query and get a value, then the DataTable is updated with that value, True or False. No need to check, just update.
Write-Host "`nAdding 'IsEnabled' column to Data Table, checking user account status and populating values..." -ForegroundColor Green
$SearchRow = $null
foreach  ($sid in $($DataTable.Sid)){
    $Enabled = $(Get-ADUser -Filter {Sid -like $sid} | select Enabled).Enabled
    #Find the record in DataTable and update the enabled column
    $SearchRow = $DataTable.where({$_.Sid -eq $($sid)})
    #If the row has a value, shove it in.
    if($Enabled -ne $null){
        $SearchRow[0].IsEnabled = $Enabled
    } 
}
Write-Host "Finished Adding 'IsEnabled' values...`n" -ForegroundColor Green

Write-Host "Adding a column for each AD Group to the Data Table..." -ForegroundColor Green
#ADD A Column for each Group in the list
foreach ($g in $TFSGroups) {
 write-host "   Adding column $g" -ForegroundColor Yellow
 $DataTable.Columns.Add("$g","System.Boolean") | Out-Null
 #$g.DefaultValue = $false
}
Write-Host "Group columns added..." -ForegroundColor Green
#Get recursive list of all users by AD Group we're searching
Write-Host "`nGetting list of all users by AD Group, searching recursively  " -ForegroundColor Green
$TotalGroups = $($TFSGroups.Count)
$HashGroups = @{}

for ($i = 0;$i -lt $($TotalGroups);$i++) {
    Write-Progress -Activity "Processing $($TFSGroups[$i])" -Status "$($i) out of $TotalGroups completed"
    $GroupMmbrs = Get-ADGroupMember -Identity $TFSGroups[$i] -Recursive | Select-Object name,distinguishedName,ObjectClass,SamAccountName,SID
    $HashGroups[$($TFSGroups[$i])] = $GroupMmbrs
    
}

Write-Host "Checking DataTable for Group memberships" -ForegroundColor Green
$SearchRow = $null #initialize SearchRow variable
#Look for only users that are Enabled in AD?  Maybe change this?
#Note for cases where the user account doesn't exist in AD, Some fields are Blank
$i = 1
foreach ($user in $($DataTable | Select AccountName, IsEnabled | Where-Object {$_.IsEnabled -eq $true} ).AccountName) {
        Write-Progress -Activity "Processing $user" -Status "$($i) of $($($DataTable.AccountName).count) users"
        Write-Host "Checking User $user" -ForegroundColor Green
        foreach($grp in $HashGroups.Keys){

            #Write-Host "   $grp" -ForegroundColor Yellow
            if($HashGroups[$grp].SamAccountName -contains $user){
                #Write-Host "$user is a member of $grp" -ForegroundColor Green
                $SearchRow = $DataTable.where({$_.AccountName -eq $($user)})
                $SearchRow[0].$grp = $true
            } else {
                    #Write-Host "$user is NOT a member of $grp" -ForegroundColor Red
                    $SearchRow = $DataTable.where({$_.AccountName -eq $($user)})
                    $SearchRow[0].$grp = $false
                    }




    }
    $i++
}

$DataTable | ConvertTo-Csv | Out-File c:\temp\TFSAudit.csv